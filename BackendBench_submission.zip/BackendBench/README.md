# BackendBench: Real-World Python Backend Reliability Evaluation

## Short description
BackendBench evaluates whether language models can repair subtle Python backend defects involving security, correctness, concurrency, transactions, and operational reliability. It contains ten self-contained coding tasks with executable contract tests and a deterministic grader. The benchmark is designed to distinguish plausible explanations from fixes that actually satisfy edge-case behavior. **No model scores are included or claimed until a run is performed.**

## Video walkthrough
Add your public, audio-enabled walkthrough URL here before submission:
`VIDEO_URL_REQUIRED`

## Domain and expertise
Domain: Python backend engineering, API development, application security, data integrity, and asynchronous systems. The benchmark is grounded in common backend engineering concerns: validating untrusted input, enforcing authorization, safely retrying operations, verifying webhooks, handling TTL caches, preserving transactional integrity, bounding concurrency, mapping errors safely, and implementing idempotency. The author should review every task and confirm the reference implementation and expected behavior before submission.

## What it tests and why it matters
BackendBench asks a model to diagnose a buggy implementation and return a complete corrected Python module. Each task includes a behavioral contract, a buggy starter, and a JSON response schema. Candidate code is executed against pytest contract tests in an isolated temporary directory. This measures executable behavior rather than accepting an explanation as proof of correctness.

Task coverage:
1. Defensive pagination normalization: bool/int confusion, invalid values, caps, and offset calculation.
2. Bearer-token extraction: malformed headers, scheme case, and whitespace.
3. Fail-closed authorization: missing ownership metadata and default-deny behavior.
4. Retry policy: transient versus permanent exceptions, attempt count, exponential delay, and final re-raise.
5. Webhook HMAC: exact raw bytes, optional prefix, malformed signatures, and constant-time comparison.
6. TTL cache: injected clock, positive TTL, and expiration boundary.
7. Atomic account transfer: validation, rollback, and preserving caller transaction boundaries via SAVEPOINT.
8. Bounded async fan-out: concurrency cap, stable result order, cancellation, and exception propagation.
9. Safe HTTP error mapping: correct status categories and no exception-message leakage.
10. Idempotency store: fingerprint binding, replay, validation, and not caching failed operations.

## Scoring methodology
Each task is scored out of 100:
- Functional correctness: up to 90 points, proportional to contract tests passed.
- Diagnosis: up to 10 points, based on the presence of task-specific diagnostic concepts.

The functional portion is computed as `round(90 * passed_tests / total_tests)`. The diagnosis portion is a transparent keyword checklist in `tasks/manifest.json`, not an LLM judge. This avoids a second model making subjective pass/fail decisions. The keyword score is only a coarse explanation check; the executable tests carry 90% of the score. A missing/invalid JSON response receives 0.

The current contract tests are deterministic and run locally. They are not a security proof and do not establish cross-process safety where a task explicitly excludes it. Review task contracts before comparing scores.

## Setup and run instructions

### Requirements
- Python 3.10+
- pip
- pytest (installed from requirements.txt)
- An OpenAI-compatible chat-completions endpoint for model runs, or a local compatible server such as Ollama.
- Network access to the chosen endpoint for API-based runs.

### Install and verify
```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python scripts/verify_reference.py
```

### Run one task manually
Open `tasks/<task_id>/prompt.md`, send it to the model, and save the model's exact response body as `response.json`. The response must be a JSON object with `diagnosis` and `fixed_code` fields.
```bash
python -m runner.grade --task task_01_pagination --response response.json --output-dir results/manual
```

### Run all tasks against an OpenAI-compatible endpoint
Set environment variables (do not commit secrets):
```bash
export BACKENDBENCH_BASE_URL="https://api.openai.com/v1"
export BACKENDBENCH_API_KEY="YOUR_KEY"
export BACKENDBENCH_MODEL="YOUR_EXACT_MODEL_ID"
python scripts/run_eval.py --label frontier --temperature 0
```

### Run against a local Ollama-compatible endpoint
Start Ollama and pull a model separately, then:
```bash
export BACKENDBENCH_BASE_URL="http://localhost:11434/v1"
export BACKENDBENCH_API_KEY="ollama"
export BACKENDBENCH_MODEL="YOUR_LOCAL_MODEL_TAG"
python scripts/run_eval.py --label open_model --temperature 0
```
The runner expects `/chat/completions` at the base URL and an OpenAI-compatible response schema. If your local provider differs, adapt the small `call_model` function and document the change.

### Runtime and cost
A full run sends ten prompts per model. Runtime and API cost depend on model latency, output length, provider pricing, and retry/rate-limit behavior. No fixed cost is asserted. Record actual elapsed time and provider-reported token usage from the generated metadata. For a local model, cost depends on hardware and electricity and is not estimated here.

## Models tested and results
**Not yet run.** Do not claim results until `scripts/run_eval.py` has completed successfully. For every model, preserve:
- Exact provider and model ID/version returned or configured.
- Date/time and endpoint.
- Temperature and other generation settings.
- Raw response files under `results/<label>/<run_id>/raw_outputs/`.
- `summary.json` and per-task grading JSON files.

The runner records requested model ID, temperature, timestamp, response ID where available, and token usage where returned. Add provider-reported version/build metadata manually if the API does not return it. Repeat runs if you want to measure variance; do not compare runs with materially different settings as if they were identical.

## Failure analysis
Populate this section after running models. Inspect per-task failures and raw outputs. Categorize failures by violated contract (e.g., boolean accepted as integer, authorization default-allow, retrying permanent exceptions, stale cache at exact expiry, non-atomic transfer, or unbounded concurrency). Include representative examples and explain whether failures are code defects, misunderstood requirements, malformed output, or grader/test limitations. **Do not write model-specific conclusions before observing actual outputs.**

## Prior work and sources
This is an original, small task suite authored for this evaluation. It is not presented as an established benchmark or as a statistically validated measure of general coding ability. The scenarios are inspired by recurring backend engineering practices and standard Python behavior. No external dataset is bundled. If you adapt a task from documentation, a public benchmark, or another source, cite it here and disclose the adaptation. Add relevant documentation links you personally consulted during final verification.

## Reproducibility and limitations
- Python and pytest versions should be recorded with each published run.
- The grader runs candidate code in a temporary directory with a 30-second test timeout.
- This is process isolation, **not a hardened sandbox**. Do not execute untrusted model code on a machine containing secrets or sensitive files. Prefer a disposable container/VM with no credentials and restricted network access.
- Tests are finite and can be overfit. Keep task prompts and scoring versioned; changing tests changes benchmark results.
- Diagnosis keyword scoring is intentionally simple and may miss valid synonyms or reward keyword stuffing. Report it separately from functional correctness.
- The bundled tasks are single-process unless the contract explicitly states otherwise. In particular, the idempotency store does not claim distributed locking or cross-process atomicity.

## Project structure
```text
BackendBench/
├── README.md
├── requirements.txt
├── .env.example
├── tasks/
│   ├── manifest.json
│   └── task_*/ (prompt.md, starter.py, reference_solution.py, test_contract.py)
├── runner/grade.py
├── scripts/run_eval.py
├── scripts/verify_reference.py
└── results/
```

## Submission checklist
- [ ] Replace `VIDEO_URL_REQUIRED` with a public video link (max 5 minutes, audio enabled).
- [ ] Run `python scripts/verify_reference.py` from a clean environment.
- [ ] Run each selected model and preserve raw outputs and scores.
- [ ] Record exact model IDs/versions, run date, settings, and token usage.
- [ ] Write failure analysis based only on observed results.
- [ ] Add actual runtime/cost notes.
- [ ] Confirm no secrets or private data are in the ZIP.
