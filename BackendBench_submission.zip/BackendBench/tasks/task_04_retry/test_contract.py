import candidate
import pytest

class TemporaryError(Exception): pass
class PermanentError(Exception): pass

def test_success_first_try():
    assert candidate.call_with_retry(lambda: 42, (TemporaryError,), 3, lambda _: None) == 42

def test_retries_transient_with_exponential_delays():
    calls, delays = {"n": 0}, []
    def op():
        calls["n"] += 1
        if calls["n"] < 3: raise TemporaryError("temporary")
        return "ok"
    assert candidate.call_with_retry(op, (TemporaryError,), 4, delays.append) == "ok"
    assert calls["n"] == 3
    assert delays == [0.1, 0.2]

def test_permanent_error_is_not_retried():
    calls = {"n": 0}
    def op():
        calls["n"] += 1
        raise PermanentError("no")
    with pytest.raises(PermanentError):
        candidate.call_with_retry(op, (TemporaryError,), 5, lambda _: None)
    assert calls["n"] == 1

def test_final_transient_error_is_reraised():
    calls = {"n": 0}
    def op():
        calls["n"] += 1
        raise TemporaryError("last")
    with pytest.raises(TemporaryError, match="last"):
        candidate.call_with_retry(op, (TemporaryError,), 2, lambda _: None)
    assert calls["n"] == 2

@pytest.mark.parametrize("n", [0, -1, True, 1.5])
def test_invalid_attempts(n):
    with pytest.raises(ValueError):
        candidate.call_with_retry(lambda: 1, (TemporaryError,), n, lambda _: None)
