# Retry only transient failures

## Domain gap
Models often retry every exception, causing repeated side effects for permanent errors, or mishandle attempt counts.

## Task
Implement call_with_retry(operation, retry_on, max_attempts, sleep). max_attempts includes the first call and must be >=1. Retry only exceptions that are instances of retry_on. Call sleep(delay) before each retry, with delays 0.1, 0.2, 0.4... seconds. Return the operation result. Re-raise the final exception unchanged. Invalid max_attempts raises ValueError.

## Buggy starter code
```python
def call_with_retry(operation, retry_on, max_attempts, sleep):
    # BUG: retries all exceptions and uses the wrong attempt/delay behavior.
    for attempt in range(max_attempts):
        try:
            return operation()
        except Exception:
            if attempt == max_attempts:
                raise
            sleep(1)
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
