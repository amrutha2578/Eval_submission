def call_with_retry(operation, retry_on, max_attempts, sleep):
    # BUG: retries all exceptions and uses the wrong attempt/delay behavior.
    for attempt in range(max_attempts):
        try:
            return operation()
        except Exception:
            if attempt == max_attempts:
                raise
            sleep(1)
