def call_with_retry(operation, retry_on, max_attempts, sleep):
    if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")
    delay = 0.1
    for attempt in range(max_attempts):
        try:
            return operation()
        except retry_on:
            if attempt == max_attempts - 1:
                raise
            sleep(delay)
            delay *= 2
