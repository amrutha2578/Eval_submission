class IdempotencyStore:
    def __init__(self):
        self.results = {}

    def execute(self, key, request_fingerprint, operation):
        # BUG: ignores request identity and caches exceptions as if they were results.
        if key in self.results:
            return self.results[key]
        try:
            result = operation()
        except Exception as exc:
            self.results[key] = exc
            raise
        self.results[key] = result
        return result
