# Idempotent request result store

## Domain gap
Models often treat a key as sufficient without binding it to request identity, enabling accidental replay of a different operation.

## Task
Implement IdempotencyStore with execute(key, request_fingerprint, operation). First call for a key executes operation once and stores its result. Repeating the same key and fingerprint returns the stored result without executing again. Reusing a key with a different fingerprint raises ValueError. Empty/non-string key or fingerprint raises ValueError. If operation raises, do not cache the failure; a later call may retry. This class is single-process and does not claim cross-process concurrency safety.

## Buggy starter code
```python
class IdempotencyStore:
    def __init__(self):
        self.results = {}

    def execute(self, key, request_fingerprint, operation):
        # BUG: ignores request identity and caches exceptions as if they were results.
        if key in self.results:
            return self.results[key]
        try:
            result = operation()
        except Exception as exc:
            self.results[key] = exc
            raise
        self.results[key] = result
        return result
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
