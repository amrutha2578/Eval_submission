class IdempotencyStore:
    def __init__(self):
        self.results = {}

    def execute(self, key, request_fingerprint, operation):
        if not isinstance(key, str) or not key.strip():
            raise ValueError("key must be a non-empty string")
        if not isinstance(request_fingerprint, str) or not request_fingerprint.strip():
            raise ValueError("request_fingerprint must be a non-empty string")
        if key in self.results:
            stored_fingerprint, stored_result = self.results[key]
            if stored_fingerprint != request_fingerprint:
                raise ValueError("idempotency key reused for a different request")
            return stored_result
        result = operation()
        self.results[key] = (request_fingerprint, result)
        return result
