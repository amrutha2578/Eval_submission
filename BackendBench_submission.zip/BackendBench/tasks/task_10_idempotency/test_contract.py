import candidate
import pytest

def test_first_call_executes_and_stores():
    store = candidate.IdempotencyStore()
    calls = {"n": 0}
    def op():
        calls["n"] += 1
        return {"id": 12}
    assert store.execute("k1", "fp-a", op) == {"id": 12}
    assert calls["n"] == 1

def test_same_request_replays_result():
    store = candidate.IdempotencyStore()
    calls = {"n": 0}
    def op():
        calls["n"] += 1
        return calls["n"]
    assert store.execute("k", "same", op) == 1
    assert store.execute("k", "same", op) == 1
    assert calls["n"] == 1

def test_key_reuse_for_different_request_rejected():
    store = candidate.IdempotencyStore()
    store.execute("k", "fp-a", lambda: "first")
    with pytest.raises(ValueError):
        store.execute("k", "fp-b", lambda: "second")

def test_failed_operation_is_not_cached():
    store = candidate.IdempotencyStore()
    calls = {"n": 0}
    def flaky():
        calls["n"] += 1
        if calls["n"] == 1: raise RuntimeError("temporary")
        return "recovered"
    with pytest.raises(RuntimeError):
        store.execute("k", "fp", flaky)
    assert store.execute("k", "fp", flaky) == "recovered"
    assert calls["n"] == 2

@pytest.mark.parametrize("key,fp", [("", "fp"), (" ", "fp"), (None, "fp"), ("k", ""), ("k", None)])
def test_invalid_identity_rejected(key, fp):
    with pytest.raises(ValueError):
        candidate.IdempotencyStore().execute(key, fp, lambda: 1)
