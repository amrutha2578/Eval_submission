def to_http_error(exc):
    # BUG: leaks internal exception details and maps all errors identically.
    return 500, {"error": str(exc)}
