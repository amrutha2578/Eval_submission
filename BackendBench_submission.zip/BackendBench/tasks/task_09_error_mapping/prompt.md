# Safe HTTP error mapping

## Domain gap
Models often leak exception messages or map all exceptions to success/server errors without distinguishing expected client failures.

## Task
Implement to_http_error(exc) -> tuple[int, dict]. Map ValueError to (400, {'error':'bad_request'}), PermissionError to (403, {'error':'forbidden'}), LookupError to (404, {'error':'not_found'}), and all other Exception instances to (500, {'error':'internal_error'}). Do not expose exception text. More specific classes listed above take precedence naturally. Non-Exception BaseException should be re-raised.

## Buggy starter code
```python
def to_http_error(exc):
    # BUG: leaks internal exception details and maps all errors identically.
    return 500, {"error": str(exc)}
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
