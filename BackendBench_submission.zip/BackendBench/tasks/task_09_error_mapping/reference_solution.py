def to_http_error(exc):
    if not isinstance(exc, Exception):
        raise exc
    if isinstance(exc, ValueError):
        return 400, {"error": "bad_request"}
    if isinstance(exc, PermissionError):
        return 403, {"error": "forbidden"}
    if isinstance(exc, LookupError):
        return 404, {"error": "not_found"}
    return 500, {"error": "internal_error"}
