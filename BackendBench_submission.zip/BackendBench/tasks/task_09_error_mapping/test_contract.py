import candidate
import pytest

@pytest.mark.parametrize("exc,expected", [
    (ValueError("sql password=secret"), (400, {"error":"bad_request"})),
    (PermissionError("private path"), (403, {"error":"forbidden"})),
    (KeyError("customer email"), (404, {"error":"not_found"})),
    (RuntimeError("database host and credentials"), (500, {"error":"internal_error"})),
    (Exception("secret"), (500, {"error":"internal_error"})),
])
def test_mapping_and_no_leak(exc, expected):
    assert candidate.to_http_error(exc) == expected

def test_base_exception_is_not_swallowed():
    class StopNow(BaseException): pass
    with pytest.raises(StopNow):
        candidate.to_http_error(StopNow("stop"))
