def normalize_pagination(page, page_size, max_page_size=100):
    if isinstance(page, bool) or not isinstance(page, int) or page < 1:
        page = 1
    if isinstance(page_size, bool) or not isinstance(page_size, int) or page_size < 1:
        page_size = 20
    if isinstance(max_page_size, bool) or not isinstance(max_page_size, int) or max_page_size < 1:
        raise ValueError("max_page_size must be a positive integer")
    page_size = min(page_size, max_page_size)
    return page, page_size, (page - 1) * page_size
