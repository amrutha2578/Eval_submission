import candidate
import pytest

def test_normal_values():
    assert candidate.normalize_pagination(3, 10) == (3, 10, 20)

@pytest.mark.parametrize("page", [0, -1, None, "2", True, 1.5])
def test_bad_page_defaults(page):
    assert candidate.normalize_pagination(page, 10) == (1, 10, 0)

@pytest.mark.parametrize("size", [0, -5, None, "10", True, 2.5])
def test_bad_size_defaults(size):
    assert candidate.normalize_pagination(2, size) == (2, 20, 20)

def test_size_is_capped_before_offset():
    assert candidate.normalize_pagination(4, 1000, 50) == (4, 50, 150)

def test_invalid_cap_is_rejected():
    with pytest.raises(ValueError):
        candidate.normalize_pagination(1, 10, 0)
