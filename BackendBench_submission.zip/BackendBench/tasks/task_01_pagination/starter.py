def normalize_pagination(page, page_size, max_page_size=100):
    # BUG: bool is accepted as int, page_size is not capped, and bad values leak through.
    if not isinstance(page, int):
        page = 1
    if not isinstance(page_size, int):
        page_size = 20
    return page, page_size, (page - 1) * page_size
