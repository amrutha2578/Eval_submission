# Defensive pagination normalization

## Domain gap
Models often implement pagination arithmetic but miss malformed, negative, boolean, and oversized inputs.

## Task
Implement normalize_pagination(page, page_size, max_page_size=100) -> tuple[int, int, int]. Return (normalized_page, normalized_page_size, offset). page must be an integer >= 1; otherwise use 1. page_size must be an integer >= 1; otherwise use 20. Clamp page_size to max_page_size. Treat bool as invalid even though bool subclasses int. offset=(page-1)*page_size.

## Buggy starter code
```python
def normalize_pagination(page, page_size, max_page_size=100):
    # BUG: bool is accepted as int, page_size is not capped, and bad values leak through.
    if not isinstance(page, int):
        page = 1
    if not isinstance(page_size, int):
        page_size = 20
    return page, page_size, (page - 1) * page_size
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
