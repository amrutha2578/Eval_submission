def can_access(user, resource):
    # BUG: missing owner metadata accidentally grants access.
    if user.get("role") == "admin":
        return True
    return resource.get("owner_id") is None or user.get("id") == resource.get("owner_id")
