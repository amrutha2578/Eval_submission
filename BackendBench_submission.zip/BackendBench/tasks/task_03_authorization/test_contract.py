import candidate
import pytest

def test_owner_allowed():
    assert candidate.can_access({"id": 7, "role": "user"}, {"owner_id": 7}) is True

def test_other_user_denied():
    assert candidate.can_access({"id": 8}, {"owner_id": 7}) is False

def test_admin_allowed():
    assert candidate.can_access({"role": "admin"}, {}) is True

@pytest.mark.parametrize("user,resource", [
    ({"id": 1}, {}),
    ({"id": None}, {"owner_id": None}),
    ({}, {"owner_id": 1}),
    (None, {"owner_id": 1}),
    ({"id": 1}, None),
    ("admin", {"owner_id": 1}),
])
def test_malformed_or_missing_metadata_denied(user, resource):
    assert candidate.can_access(user, resource) is False

def test_non_admin_role_does_not_bypass():
    assert candidate.can_access({"id": 1, "role": "superuser"}, {"owner_id": 2}) is False
