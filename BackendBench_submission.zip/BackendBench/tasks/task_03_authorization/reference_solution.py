from collections.abc import Mapping

def can_access(user, resource):
    if not isinstance(user, Mapping) or not isinstance(resource, Mapping):
        return False
    if user.get("role") == "admin":
        return True
    user_id = user.get("id")
    owner_id = resource.get("owner_id")
    return user_id is not None and owner_id is not None and user_id == owner_id
