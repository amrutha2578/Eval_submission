# Fail-closed resource authorization

## Domain gap
Models often confuse authentication with authorization and accidentally grant access when ownership metadata is missing.

## Task
Implement can_access(user, resource) -> bool. user/resource are mappings. Deny if either is missing/malformed. Allow role='admin'. Otherwise allow only when user.id and resource.owner_id are both present, non-None, and equal. Never infer access from a missing owner.

## Buggy starter code
```python
def can_access(user, resource):
    # BUG: missing owner metadata accidentally grants access.
    if user.get("role") == "admin":
        return True
    return resource.get("owner_id") is None or user.get("id") == resource.get("owner_id")
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
