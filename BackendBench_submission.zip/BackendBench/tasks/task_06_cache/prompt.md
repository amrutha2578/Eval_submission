# TTL cache expiration semantics

## Domain gap
Models often use wall-clock time or expire entries at the wrong boundary, causing stale cache reads.

## Task
Implement TTLCache(clock). set(key,value,ttl_seconds) stores an entry expiring at clock()+ttl; ttl must be >0 or raise ValueError. get(key, default=None) returns default when absent or expired. An entry is expired when clock() >= expiry. Use the injected clock and do not depend on time.time().

## Buggy starter code
```python
import time

class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.data = {}

    def set(self, key, value, ttl_seconds):
        # BUG: uses wall clock rather than injected clock.
        self.data[key] = (value, time.time() + ttl_seconds)

    def get(self, key, default=None):
        item = self.data.get(key)
        if item is None:
            return default
        value, expiry = item
        # BUG: stale value survives the exact expiry boundary.
        if self.clock() > expiry:
            del self.data[key]
            return default
        return value
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
