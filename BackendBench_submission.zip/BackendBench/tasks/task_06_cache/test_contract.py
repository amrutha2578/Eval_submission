import candidate
import pytest

class FakeClock:
    def __init__(self): self.now = 100.0
    def __call__(self): return self.now

def test_value_before_expiry():
    clock = FakeClock()
    cache = candidate.TTLCache(clock)
    cache.set("k", "v", 5)
    clock.now = 104.999
    assert cache.get("k") == "v"

def test_exact_expiry_is_expired():
    clock = FakeClock()
    cache = candidate.TTLCache(clock)
    cache.set("k", "v", 5)
    clock.now = 105.0
    assert cache.get("k", "miss") == "miss"

def test_expired_entry_is_removed():
    clock = FakeClock()
    cache = candidate.TTLCache(clock)
    cache.set("k", 1, 1)
    clock.now = 102
    assert cache.get("k") is None
    assert "k" not in cache.data

@pytest.mark.parametrize("ttl", [0, -1])
def test_nonpositive_ttl_rejected(ttl):
    cache = candidate.TTLCache(FakeClock())
    with pytest.raises(ValueError):
        cache.set("k", "v", ttl)

def test_injected_clock_controls_expiration():
    clock = FakeClock()
    cache = candidate.TTLCache(clock)
    cache.set("k", 9, 10)
    clock.now += 9
    assert cache.get("k") == 9
