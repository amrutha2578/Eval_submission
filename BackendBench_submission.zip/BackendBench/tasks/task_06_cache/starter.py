import time

class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.data = {}

    def set(self, key, value, ttl_seconds):
        # BUG: uses wall clock rather than injected clock.
        self.data[key] = (value, time.time() + ttl_seconds)

    def get(self, key, default=None):
        item = self.data.get(key)
        if item is None:
            return default
        value, expiry = item
        # BUG: stale value survives the exact expiry boundary.
        if self.clock() > expiry:
            del self.data[key]
            return default
        return value
