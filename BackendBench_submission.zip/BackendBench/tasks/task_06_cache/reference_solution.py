class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.data = {}

    def set(self, key, value, ttl_seconds):
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        self.data[key] = (value, self.clock() + ttl_seconds)

    def get(self, key, default=None):
        item = self.data.get(key)
        if item is None:
            return default
        value, expiry = item
        if self.clock() >= expiry:
            del self.data[key]
            return default
        return value
