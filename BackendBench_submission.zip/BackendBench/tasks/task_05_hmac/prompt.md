# Webhook signature verification

## Domain gap
Models may verify a transformed payload, use ordinary string comparison, or mishandle malformed signatures.

## Task
Implement verify_webhook_signature(raw_body, supplied_hex, secret) -> bool. Compute HMAC-SHA256 over the exact raw_body bytes using secret encoded as UTF-8 if it is a string. supplied_hex may optionally start with 'sha256='. Compare digest using hmac.compare_digest. Return False for wrong types, malformed hex, or any mismatch. Do not parse/re-serialize JSON.

## Buggy starter code
```python
import hashlib
import hmac

def verify_webhook_signature(raw_body, supplied_hex, secret):
    # BUG: compares a normal string and doesn't handle the documented prefix safely.
    expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return expected == supplied_hex
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
