import hashlib
import hmac

def verify_webhook_signature(raw_body, supplied_hex, secret):
    # BUG: compares a normal string and doesn't handle the documented prefix safely.
    expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return expected == supplied_hex
