import candidate
import hashlib, hmac

def sign(body, secret=b"secret"):
    return hmac.new(secret, body, hashlib.sha256).hexdigest()

def test_valid_signature():
    body = b'{"amount":10}'
    assert candidate.verify_webhook_signature(body, sign(body), "secret") is True

def test_prefix_supported():
    body = b"exact bytes"
    assert candidate.verify_webhook_signature(body, "sha256=" + sign(body), b"secret") is True

def test_raw_bytes_are_not_normalized():
    assert candidate.verify_webhook_signature(b'{"a":1}', sign(b'{"a":1}'), "secret")
    assert not candidate.verify_webhook_signature(b'{ "a": 1 }', sign(b'{"a":1}'), "secret")

def test_tampered_body_and_signature_rejected():
    body = b"payload"
    assert not candidate.verify_webhook_signature(body + b"x", sign(body), "secret")
    assert not candidate.verify_webhook_signature(body, "0" * 64, "secret")

def test_malformed_inputs_return_false():
    assert candidate.verify_webhook_signature("body", "abc", "secret") is False
    assert candidate.verify_webhook_signature(b"body", "not-hex", "secret") is False
    assert candidate.verify_webhook_signature(b"body", None, "secret") is False
