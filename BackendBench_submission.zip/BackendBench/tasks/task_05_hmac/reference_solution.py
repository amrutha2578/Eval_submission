import hashlib
import hmac

def verify_webhook_signature(raw_body, supplied_hex, secret):
    if not isinstance(raw_body, bytes) or not isinstance(supplied_hex, str):
        return False
    if isinstance(secret, str):
        secret = secret.encode("utf-8")
    if not isinstance(secret, bytes):
        return False
    signature = supplied_hex
    if signature.startswith("sha256="):
        signature = signature[len("sha256="):]
    try:
        bytes.fromhex(signature)
    except ValueError:
        return False
    expected = hmac.new(secret, raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature.lower())
