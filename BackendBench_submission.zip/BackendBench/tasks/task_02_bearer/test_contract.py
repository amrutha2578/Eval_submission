import candidate
import pytest

@pytest.mark.parametrize("header,expected", [
    ("Bearer abc.def", "abc.def"),
    ("bearer token123", "token123"),
    ("BEARER x", "x"),
    ("  Bearer   abc  ", "abc"),
    ("Basic abc", None),
    ("Bearer", None),
    ("Bearer ", None),
    ("Bearer a b", None),
    ("Bearer\\tabc", None),
    ("", None),
    (None, None),
    (123, None),
    (["Bearer", "x"], None),
])
def test_headers(header, expected):
    assert candidate.extract_bearer_token(header) == expected
