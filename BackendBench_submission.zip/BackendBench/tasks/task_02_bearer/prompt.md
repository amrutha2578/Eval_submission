# Robust bearer-token extraction

## Domain gap
Models frequently write permissive header parsing that accepts malformed schemes, whitespace, or empty credentials.

## Task
Implement extract_bearer_token(authorization) -> str | None. Accept a string with exactly two whitespace-separated parts; scheme comparison is case-insensitive and must be Bearer; token must be non-empty and contain no whitespace. Return token or None. Do not raise for non-string inputs.

## Buggy starter code
```python
def extract_bearer_token(authorization):
    # BUG: accepts any scheme and can return an empty or malformed token.
    if authorization:
        return authorization.split(" ")[-1]
    return None
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
