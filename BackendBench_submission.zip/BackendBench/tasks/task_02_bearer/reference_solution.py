def extract_bearer_token(authorization):
    if not isinstance(authorization, str):
        return None
    parts = authorization.strip().split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    token = parts[1]
    if not token or any(ch.isspace() for ch in token):
        return None
    return token
