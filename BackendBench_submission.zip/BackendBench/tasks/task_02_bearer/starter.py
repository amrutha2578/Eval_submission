def extract_bearer_token(authorization):
    # BUG: accepts any scheme and can return an empty or malformed token.
    if authorization:
        return authorization.split(" ")[-1]
    return None
