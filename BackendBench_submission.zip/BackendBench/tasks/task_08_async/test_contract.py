import candidate
import asyncio
import pytest

def test_empty_input():
    assert asyncio.run(candidate.async_map_bounded([], lambda x: x, 2)) == []

def test_preserves_input_order_and_limits_concurrency():
    async def scenario():
        active = 0
        peak = 0
        async def worker(x):
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            await asyncio.sleep((5-x) * 0.002)
            active -= 1
            return x * 10
        result = await candidate.async_map_bounded([1,2,3,4,5], worker, 2)
        assert result == [10,20,30,40,50]
        assert peak <= 2
        assert peak >= 2
    asyncio.run(scenario())

@pytest.mark.parametrize("limit", [0, -1, True, 1.5])
def test_invalid_limit(limit):
    with pytest.raises(ValueError):
        asyncio.run(candidate.async_map_bounded([1], lambda x: x, limit))

def test_worker_exception_propagates():
    async def scenario():
        async def worker(x):
            if x == 2: raise RuntimeError("worker failed")
            await asyncio.sleep(0.01)
            return x
        with pytest.raises(RuntimeError, match="worker failed"):
            await candidate.async_map_bounded([1,2,3,4], worker, 2)
    asyncio.run(scenario())
