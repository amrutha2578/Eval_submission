import asyncio

async def async_map_bounded(items, worker, limit):
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise ValueError("limit must be a positive integer")
    semaphore = asyncio.Semaphore(limit)
    async def run_one(item):
        async with semaphore:
            return await worker(item)
    tasks = [asyncio.create_task(run_one(item)) for item in items]
    try:
        return await asyncio.gather(*tasks)
    except BaseException:
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        raise
