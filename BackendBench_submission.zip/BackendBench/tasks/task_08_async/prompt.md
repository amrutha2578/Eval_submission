# Bounded async fan-out with stable ordering

## Domain gap
Models often use gather without concurrency limits, or accidentally return completion order instead of input order.

## Task
Implement async_map_bounded(items, worker, limit). Run worker(item) concurrently with at most limit calls in flight. Return results in the same order as items, not completion order. Empty input returns []. limit must be a positive integer; bool invalid. If a worker raises, propagate the exception and cancel outstanding work before returning.

## Buggy starter code
```python
import asyncio

async def async_map_bounded(items, worker, limit):
    # BUG: no concurrency bound; result ordering happens to depend on gather semantics.
    return await asyncio.gather(*(worker(item) for item in items))
```

## Required response format
Return exactly one JSON object, with no Markdown fences:
{
  "diagnosis": "A concise explanation of the root cause and relevant edge cases.",
  "fixed_code": "The complete corrected Python module as a JSON string."
}

The fixed module must preserve the required public function/class names and signatures. Do not omit imports. Do not change the contract. Your code will be executed against tests, including edge cases. Explain why the fix addresses the bug, but prioritize executable correctness.
