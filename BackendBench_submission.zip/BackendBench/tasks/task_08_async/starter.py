import asyncio

async def async_map_bounded(items, worker, limit):
    # BUG: no concurrency bound; result ordering happens to depend on gather semantics.
    return await asyncio.gather(*(worker(item) for item in items))
